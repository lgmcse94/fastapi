
import uuid

from sqlalchemy import Column, String, DateTime
from sqlalchemy.dialects.mysql import UUID
from sqlalchemy.sql import func
from sqlalchemy.sql.sqltypes import Boolean

from db import base


class AllDBs(base):
    __tablename__ = 'alldbs'
    #__table_args__ = {'schema': 'paytm'}

    id = Column(UUID(as_uuid=True), primary_key=True, index=True, default=uuid.uuid4)
    db_type = Column(String)
    db_name = Column(String)
    db_endpoint = Column(String)
    password = Column(String)
    is_active = Column(Boolean, default=True)
    created_by = Column(String)
    modified_by = Column(String)
    created_date = Column(DateTime(timezone=False), server_default=func.now())
    modified_date = Column(DateTime(timezone=False), onupdate=func.now())

    def __repr__(self):
        return (
            f"<AllDBs(id = {self.id},db_type = {self.db_type}, "
            f"db_name = {self.db_name},db_endpoint = {self.db_endpoint},"
            f"password = {self.password},is_active = {self.is_active},"
            f"created_by = {self.created_by},modified_by = {self.modified_by},"
            f"created_date = {self.created_date},modified_date = {self.modified_date})>")
